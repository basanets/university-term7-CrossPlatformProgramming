module SightsHelper
end
