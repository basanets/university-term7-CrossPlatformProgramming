class Sight < ApplicationRecord
  belongs_to :city
end
