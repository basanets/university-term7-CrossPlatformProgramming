require 'test_helper'

class SightTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
