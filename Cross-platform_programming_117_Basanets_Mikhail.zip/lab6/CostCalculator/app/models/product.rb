class Product < ApplicationRecord
end
