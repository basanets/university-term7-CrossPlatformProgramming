class HelloController < ApplicationController
  def index
  end
end
