class CommunalServiceRecord < ApplicationRecord
end
